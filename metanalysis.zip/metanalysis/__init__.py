from .api import RiotAPI

__all__ = ['RiotAPI']